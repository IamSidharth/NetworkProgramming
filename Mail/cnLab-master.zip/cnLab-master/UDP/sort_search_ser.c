#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<arpa/inet.h>
#include<netinet/in.h>
#include<unistd.h> 

/* netinet/in.h for structures
   sys/types for datatypes
   skt for socket system calls
   arpa/inet for conversion functions
   unistd for close() call
*/
int linear_search(int* arr,int n,int key){
	int i=0;
	for(i=0;i<n;i++)
		if(arr[i]==key)
			return i;
	return -1;
}
int binary_search(int* arr,int n,int key){
	int l = 0;
	int r = n-1;
	int mid;
	while(l<=r){
		mid = l + (r-l)/2;
		if(arr[mid]==key)
			return mid;
		else if(arr[mid]<key)
			l = mid+1;
		else
			r = mid-1;
	}
	return -1;
}
 
int partition(int a[],int l,int u)
{
    int v,i,j,temp;
    v=a[l];
    i=l;
    j=u+1;
    
    do
    {
        do
            i++;
            
        while(a[i]<v&&i<=u);
        
        do
            j--;
        while(v<a[j]);
        
        if(i<j)
        {
            temp=a[i];
            a[i]=a[j];
            a[j]=temp;
        }
    }while(i<j);
    
    a[l]=a[j];
    a[j]=v;
    
    return(j);
}

void quick_sort(int a[],int l,int u)
{
    int j;
    if( l < u)
    {
        j=partition(a,l,u);
        quick_sort(a,l,j-1);
        quick_sort(a,j+1,u);
    }
}

void merge(int arr[], int l, int m, int r) 
{ 
    int i, j, k; 
    int n1 = m - l + 1; 
    int n2 =  r - m; 

    int L[n1], R[n2]; 

    for (i = 0; i < n1; i++) 
        L[i] = arr[l + i]; 
    for (j = 0; j < n2; j++) 
        R[j] = arr[m + 1+ j]; 
  
    i = 0;  
    j = 0; 
    k = l; 
    while (i < n1 && j < n2) 
    { 
        if (L[i] <= R[j]) 
        { 
            arr[k] = L[i]; 
            i++; 
        } 
        else
        { 
            arr[k] = R[j]; 
            j++; 
        } 
        k++; 
    } 
    
    while (i < n1) 
    { 
        arr[k] = L[i]; 
        i++; 
        k++; 
    } 
  
    while (j < n2) 
    { 
        arr[k] = R[j]; 
        j++; 
        k++; 
    } 
} 

void mergeSort(int arr[], int l, int r) 
{ 
    if (l < r) 
    { 
        int m = l+(r-l)/2; 
  
        mergeSort(arr, l, m); 
        mergeSort(arr, m+1, r); 
  
        merge(arr, l, m, r); 
    } 
} 

int main(){
	
int skt = socket(PF_INET,SOCK_DGRAM,0);

if(skt == -1){
	perror("Error creating skt");
	exit(1);
}

struct sockaddr_in server,client;
server.sin_family = AF_INET;
server.sin_addr.s_addr = inet_addr("127.0.0.1");
server.sin_port = htons(30000);

int b = bind(skt,(struct sockaddr *)&server,sizeof(server));
if(b == -1){
	perror("Error binding");
	exit(1);
}
int i;
while(1){

int cl_size;
int arr[100];
int size;

recvfrom(skt,&size,sizeof(size),0,(struct sockaddr*)&client,&cl_size);//recv size
recvfrom(skt,arr,sizeof(arr),0,(struct sockaddr*)&client,&cl_size);//rec
printf("received array\n");
int ch=5,key,ans;
recvfrom(skt,&ch,sizeof(int),0,(struct sockaddr*)&client,&cl_size);
switch(ch){
case 1:
	recvfrom(skt,&key,sizeof(key),0,(struct sockaddr*)&client,&cl_size);
	ans = binary_search(arr,size,key);
	sendto(skt,&ans,sizeof(ans),0,(struct sockaddr*)&client,cl_size);
	break;
case 2:
	mergeSort(arr,0,size-1);
	sendto(skt,arr,sizeof(arr),0,(struct sockaddr*)&client,cl_size);
	break;
case 3:
	quick_sort(arr,0,size-1);
	sendto(skt,arr,sizeof(arr),0,(struct sockaddr*)&client,cl_size);
	break;
case 4:
	recvfrom(skt,&key,sizeof(key),0,(struct sockaddr*)&client,&cl_size);
	ans = linear_search(arr,size,key);
	sendto(skt,&ans,sizeof(ans),0,(struct sockaddr*)&client,cl_size);
	break;
case 5:
	exit(1);
}
}
return 0;
}
