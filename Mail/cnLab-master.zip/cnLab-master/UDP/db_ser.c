/************* UDP SERVER CODE *******************/

#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <stdlib.h>
#define MAX 100

struct book
{
	char title[MAX],author[MAX],accno[MAX],totalpgs[MAX],publisher[MAX];
} db1[3];
void populate()
{
	sprintf(db1[0].title,"harrypotter");
	sprintf(db1[0].author,"jkrowling");
	sprintf(db1[0].accno,"1234");
	sprintf(db1[0].totalpgs,"400");
	sprintf(db1[0].publisher,"couk");

	sprintf(db1[1].title,"percyjackson");
	sprintf(db1[1].author,"drjohn");
	sprintf(db1[1].accno,"1235");
	sprintf(db1[1].totalpgs,"500");
	sprintf(db1[1].publisher,"earthen co ltd");

	sprintf(db1[2].title,"goosebumps");
	sprintf(db1[2].author,"vala");
	sprintf(db1[2].accno,"1295");
	sprintf(db1[2].totalpgs,"200");
	sprintf(db1[2].publisher,"gm publcations");



}

int main(){
  int udpSocket, nBytes;
  char buffer[MAX],buff[MAX];
  struct sockaddr_in serverAddr, clientAddr;
  struct sockaddr_storage serverStorage;
  socklen_t addr_size, client_addr_size;
  int i;

  /*Create UDP socket*/
  udpSocket = socket(PF_INET, SOCK_DGRAM, 0);

  /*Configure settings in address struct*/
  serverAddr.sin_family = AF_INET;
  serverAddr.sin_port = htons(7891);
  serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
  memset(serverAddr.sin_zero, '\0', sizeof serverAddr.sin_zero);  

  /*Bind socket with address struct*/
  bind(udpSocket, (struct sockaddr *) &serverAddr, sizeof(serverAddr));

  /*Initialize size variable to be used later on*/
  addr_size = sizeof serverStorage;
  populate();


  while(1){
    /* Try to receive any incoming UDP datagram. Address and port of 
      requesting client will be stored on serverStorage variable */
    nBytes = recvfrom(udpSocket,buffer,100,0,(struct sockaddr *)&serverStorage, &addr_size);

    printf("message from client: %s\n",buffer);	

	if(strcasecmp(buffer,"EXIT")==0)
		{
			break;
		}
		else
		{
			int i,f=0;
			for(i=0;i<3;i++)
			{
	
				if(strcmp(buffer,db1[i].title)==0)
				{
					f=1;
					break;
				}
			}


			if(f==1)
			{
				sprintf(buff,"title - %s\nauthor - %s\naccno - %s\ntotal pgs - %s\npublisher - %s\n",db1[i].title,db1[i].author,db1[i].accno,db1[i].totalpgs,db1[i].publisher);
			}

			else if(f==0)
				{sprintf(buff,"Record not found");}
	
	/*Send uppercase message back to client, using serverStorage as the address*/
	    sendto(udpSocket,buff,sizeof(buff),0,(struct sockaddr *)&serverStorage,addr_size);			
		}

  }

  return 0;
}
