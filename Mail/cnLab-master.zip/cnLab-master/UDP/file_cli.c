#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<arpa/inet.h>
#include<netinet/in.h>
#include<unistd.h> 
#include<string.h>

#define BUFFSIZE 100000

/* netinet/in.h for structures
   sys/types for datatypes
   socket for socket system calls
   arpa/inet for conversion functions
   unistd for close() call
*/

int main(void){
int i;
	
int skt = socket(PF_INET,SOCK_DGRAM,0);

if(skt == -1){
	perror("Error creating socket");
	exit(1);
}

struct sockaddr_in server;
server.sin_family = AF_INET;
server.sin_addr.s_addr = inet_addr("127.0.0.1");
server.sin_port = htons(30000);
int len = sizeof(server);

char name[100];
int size,file_found=0;
//input
printf("Enter the name of the File\n");
scanf("%[^\n]%*c",name); 

sendto(skt,name,sizeof(name),0,(struct sockaddr*)&server,len);
//send file name
recvfrom(skt,&file_found,sizeof(int),0,(struct sockaddr*)&server,&len);
if(!file_found){
	printf("File Not found \n");
}

printf("Enter choice:\n");
printf("1.read File 2.Write to file 3.append to file 4.exit\n");
int ch=4,key,eve=0;
scanf("%d",&ch);
sendto(skt,&ch,sizeof(int),0,(struct sockaddr*)&server,sizeof(server));

char file_buf[BUFFSIZE];
int remain=file_found,recv_len=0;
printf("File size is : %d\n",file_found);

switch(ch){
case 1:
	//receive the File
	while((remain>0) && (recv_len = recvfrom(skt,file_buf,remain,0,(struct sockaddr*)&server,&len ))){		
	//printing the current received parts of file
	remain -= recv_len;
	for(i=0;i<recv_len;i++){
		printf("%c",file_buf[i]);
	}
	}
	break;
case 2:
	printf("Enter the text to write to the file: \n");
	getchar();
	fgets(file_buf,100,stdin);
	//read client input
	sendto(skt,file_buf,strlen(file_buf),0,(struct sockaddr*)&server,sizeof(server));
	printf("Written to file\n");
	break;
case 3:
	printf("Enter the text to append to the file: \n");
	getchar();
	fgets(file_buf,100 ,stdin);
	//read client input
	sendto(skt,file_buf,strlen(file_buf),0,(struct sockaddr*)&server,sizeof(server));
	printf("appended to file\n");
	break;
case 4:
	exit(0);
}

return 0;
}
