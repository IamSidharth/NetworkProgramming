#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<arpa/inet.h>
#include<netinet/in.h>
#include<unistd.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<string.h>

/* netinet/in.h for structures
   sys/types for datatypes
   skt for socket system calls
   arpa/inet for conversion functions
   unistd for close() call
*/


int main(){
	
int skt = socket(PF_INET,SOCK_DGRAM,0);

if(skt == -1){
	perror("Error creating skt");
	exit(1);
}

struct sockaddr_in server,client;
server.sin_family = AF_INET;
server.sin_addr.s_addr = inet_addr("127.0.0.1");
server.sin_port = htons(30000);

int b = bind(skt,(struct sockaddr *)&server,sizeof(server));
if(b == -1){
	perror("Error binding");
	exit(1);
}

while(1){

int cl_size = sizeof(client);

char name[100];
FILE* file;
struct stat buff;
int size=0;
recvfrom(skt,name,sizeof(name),0,(struct sockaddr*)&client,&cl_size);
//received name of file
if((file = fopen(name,"r"))){
	fclose(file);
	stat(name,&buff);
	size = buff.st_size;
}
else{
	printf("File does not exist\n");
}

sendto(skt,&size,sizeof(int),0,(struct sockaddr*)&client,cl_size);

int ch=4,read=0;
char file_buf[10000];
recvfrom(skt,&ch,sizeof(int),0,(struct sockaddr*)&client,&cl_size);

switch(ch){
case 1:
	file = fopen(name,"r");
	while(fgets(file_buf,10000,file)){
		sendto(skt,file_buf,strlen(file_buf),0,(struct sockaddr*)&client,cl_size);
	}
	fclose(file);
	break;
case 2:
	file = fopen(name,"w");
	read = recvfrom(skt,file_buf,sizeof(file_buf),0,(struct sockaddr*)&client,&cl_size);
	fwrite(file_buf,sizeof(char),read,file);
	fclose(file);
	break;
case 3:
	file = fopen(name,"a");
	read = recvfrom(skt,file_buf,sizeof(file_buf),0,(struct sockaddr*)&client,&cl_size);
	fwrite(file_buf,sizeof(char),read,file);
	fclose(file);
	break;
case 4:
	exit(0);
	break;
}
}
return 0;
}
