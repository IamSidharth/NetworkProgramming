#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<arpa/inet.h>
#include<netinet/in.h>
#include<unistd.h> 

/* netinet/in.h for structures
   sys/types for datatypes
   socket for socket system calls
   arpa/inet for conversion functions
   unistd for close() call
*/

int main(void){
int i;
	
int skt = socket(PF_INET,SOCK_DGRAM,0);

if(skt == -1){
	perror("Error creating socket");
	exit(1);
}

struct sockaddr_in server;
server.sin_family = AF_INET;
server.sin_addr.s_addr = inet_addr("127.0.0.1");
server.sin_port = htons(30000);

int arr[100];
int size;
//input
printf("Enter size of array and the array\n");
scanf("%d",&size);
for(i=0;i<size;i++)
	scanf("%d",&arr[i]);

sendto(skt,&size,sizeof(size),0,(struct sockaddr*)&server,sizeof(server));//send size of array
sendto(skt,arr,sizeof(arr),0,(struct sockaddr*)&server,sizeof(server));//send array

printf("Enter choice:\n");
printf("1.binary search 2.Merge Sort 3.Quick Sort 4.linear search 5.exit\n");
int ch=5,key;
scanf("%d",&ch);
sendto(skt,&ch,sizeof(int),0,(struct sockaddr*)&server,sizeof(server));
int len = sizeof(server);

switch(ch){
case 1:
	printf("Enter key to be searched:\n");
	scanf("%d",&key);
	sendto(skt,&key,sizeof(key),0,(struct sockaddr*)&server,sizeof(server));
	//sent
	recvfrom(skt,&key,sizeof(key),0,(struct sockaddr*)&server,&len);
	printf("The index is : %d",key);
	printf("\n");
	break;
case 2:
case 3:
	recvfrom(skt,arr,sizeof(arr),0,(struct sockaddr*)&server,&len);
	printf("Sorted array is \n");
	for(i=0;i<size;i++)
		printf("%d ",arr[i]);
	printf("\n");
	break;
case 4:
	printf("Enter key to be searched:\n");
	scanf("%d",&key);
	sendto(skt,&key,sizeof(key),0,(struct sockaddr*)&server,sizeof(server));
	//sent
	recvfrom(skt,&key,sizeof(key),0,(struct sockaddr*)&server,&len);
	printf("The index is : %d",key);
	printf("\n");
	break;
case 5:
	exit(0);
}
return 0;
}
