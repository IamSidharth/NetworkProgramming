#include <stdio.h>
#include <sys/socket.h> //socket , bind and connect
#include <netinet/in.h> //sockaddr_in structure
#include <arpa/inet.h>
#include <unistd.h>     //close() 
#include <stdlib.h>     //exit()
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/prctl.h>

int main(void){
	//creating tcp socket
	int sockid = socket(PF_INET,SOCK_DGRAM,0);
	if(sockid < 0 ){
		perror("error in creating socket\n");
		exit(1);
	}

	struct sockaddr_in server,client;
	server.sin_family = AF_INET;   //ip family
	server.sin_port = htons(8085); //port number
	server.sin_addr.s_addr = inet_addr("127.0.0.1"); //ip of server

	int b = bind(sockid,(struct sockaddr*)&server,sizeof(server));
	if(b == -1){
		close(sockid);
		perror("binding failed");
		exit(1);
	}
	
	int len = sizeof(client);
	char msg[100],*m2="Bye\n";
	int rec = recvfrom(sockid,msg,sizeof(msg),0,(struct sockaddr*)&client,&len);
	pid_t pid = fork();
	if(pid>0){
		while(1){
			int rec = recvfrom(sockid,msg,sizeof(msg),0,(struct sockaddr*)&client,&len); //receive reply from client
		
			if(strcmp(msg,m2)==0){
				close(sockid);
				exit(0);
			}
			printf("%s",msg);
		}
	}
	else if(pid==0){
		 int r = prctl(PR_SET_PDEATHSIG, SIGTERM); //child die when parent die
		 pid_t parent = getppid();
		 while(1){
			fgets(msg,100,stdin);
			int sen = sendto(sockid,msg,sizeof(msg),0,(struct sockaddr*)&client,len); //sending the message

			if(strcmp(msg,m2)==0){
				close(sockid);
				kill(parent,9);
			}
		}
	}

		close(sockid);
		return 0;
}
