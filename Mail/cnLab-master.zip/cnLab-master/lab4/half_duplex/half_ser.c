#include <stdio.h>
#include <sys/socket.h> //socket , bind and connect
#include <netinet/in.h> //sockaddr_in structure
#include <arpa/inet.h>
#include <unistd.h>     //close() 
#include <stdlib.h>     //exit()
#include <string.h>

int main(void){
	//creating tcp socket
	int sockid = socket(PF_INET,SOCK_STREAM,0);
	if(sockid < 0 ){
		perror("error in creating socket\n");
		exit(1);
	}

	struct sockaddr_in server,client;
	server.sin_family = AF_INET;   //ip family
	server.sin_port = htons(8086); //port number
	server.sin_addr.s_addr = inet_addr("127.0.0.1"); //ip of server

	int b = bind(sockid,(struct sockaddr*)&server,sizeof(server));
	if(b == -1){
		close(sockid);
		perror("binding failed");
		exit(1);
	}


	int status = listen(sockid,1); //queue limit 1
	if(status == -1){
		close(sockid);
		perror("listen failed");
		exit(1);
	}
	
	int len = sizeof(client);
	int con = accept(sockid,(struct sockaddr*)&client,&len);
	if(con<0){
		perror("socket() failed!!");
		exit(1);
	}

	char msg[100],*m2="Bye\n";
	while(1){
		int rec = recv(con,msg,sizeof(msg),0); //receive reply from server
		if(rec == -1){
			close(con);
			close(sockid);
			perror("receiving failed");
			exit(1);
		}
		
		if(strcmp(msg,m2)==0){
			close(con);
			break;
		}

		printf("%s",msg);
		scanf("%[^\n]%*c",msg);

		int sen = send(con,msg,sizeof(msg),0); //sending the message
		if(sen == -1){
			close(con);
			close(sockid);
			perror("sending failed");
			exit(1);
		}

		if(strcmp(msg,"Bye")==0){
			close(con);
			break;
		}
	}

	close(sockid);
	return 0;
}
