#include <stdio.h>
#include <sys/socket.h> //socket , bind and connect
#include <netinet/in.h> //sockaddr_in structure
#include <arpa/inet.h>
#include <unistd.h>     //close() 
#include <stdlib.h>     //exit()
#include <string.h>

int main(void){
	//creating tcp socket
	int sockid = socket(PF_INET,SOCK_STREAM,0);
	if(sockid < 0 ){
		perror("error in creating socket\n");
		exit(1);
	}
	
	struct sockaddr_in server;
	server.sin_family = AF_INET;   //ip family
	server.sin_port = htons(8086); //port number
	server.sin_addr.s_addr = inet_addr("127.0.0.1"); //ip of server

	int con = connect(sockid,(struct sockaddr*)&server,sizeof(server));
	if(con<0){
		perror("Connection to server failed!!");
		exit(1);
	}

	char msg[100],rec_msg[100];
	int len=0;
	while(1){
		fgets(msg,100,stdin);
		int sen = send(sockid,msg,sizeof(msg),0); //sending the message
		if(sen == -1){
			close(sockid);
			perror("sending failed");
			exit(1);
		}
		if (strcmp(msg,"Bye\n")==0){
			close(sockid);
			exit(0);
		}

		int rec = recv(sockid,rec_msg,sizeof(rec_msg),0); //receive reply from server
		if(rec == -1){
			close(sockid);
			perror("receiving failed");
			exit(1);
		}
		printf("%s\n",rec_msg);

	}
	close(sockid);
	return 0;
}
