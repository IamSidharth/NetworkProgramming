#include <stdio.h>
#include <sys/socket.h> //socket , bind and connect
#include <netinet/in.h> //sockaddr_in structure
#include <arpa/inet.h>
#include <unistd.h>     //close() 
#include <stdlib.h>     //exit()
#include <string.h>

int main(void){
	//creating tcp socket
	int sockid = socket(PF_INET,SOCK_STREAM,0);
	if(sockid < 0 ){
		perror("error in creating socket\n");
		exit(1);
	}
	
	struct sockaddr_in server;
	server.sin_family = AF_INET;   //ip family
	server.sin_port = htons(8086); //port number
	server.sin_addr.s_addr = inet_addr("127.0.0.1"); //ip of server

	int con = connect(sockid,(struct sockaddr*)&server,sizeof(server));
	if(con<0){
		perror("Connection to server failed!!");
		exit(1);
	}

	int ch;
	char send_data[100];
	printf("Enter choice\n");
	printf("1.Reg no 2.Name 3.Sub-code  ");
	scanf("%d",&ch);
	send(sockid,&ch,sizeof(int),0);
	getchar();
	scanf("%[^\n]%*c",send_data);
	send(sockid,send_data,sizeof(send_data),0);

	char name[50],address[100],dept[10],section;
	int pid,semester,marks;
	recv(sockid,&pid,sizeof(int),0);
	printf("PID of child process : %d \n",pid);
	switch(ch){
		case 1:
			recv(sockid,name,sizeof(name),0);
			recv(sockid,address,sizeof(address),0);
			printf("Name: %s\n",name);
			printf("Address: %s\n",address);
			break;			
		case 2:
			recv(sockid,dept,sizeof(dept),0);
			recv(sockid,&semester,sizeof(int),0);
			recv(sockid,&section,sizeof(char),0);
			printf("Dept: %s\n",dept);
			printf("Semester ans section : %d %c\n",semester,section);
			break;
		case 3:
			recv(sockid,&marks,sizeof(int),0);
			printf("Marks: %d\n",marks);
			break;
		}
	close(sockid);
	return 0;
}
