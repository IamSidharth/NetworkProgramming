#include <stdio.h>
#include <sys/socket.h> //socket , bind and connect
#include <netinet/in.h> //sockaddr_in structure
#include <arpa/inet.h>
#include <unistd.h>     //close() 
#include <stdlib.h>     //exit()
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/mman.h>

struct student {
	char regno[50],name[50],address[50],dept[10],section,subject_code[10];
	int semester,marks;
};
static int *glob_var;
int main(void){
	//creating tcp socket
	int sockid = socket(PF_INET,SOCK_STREAM,0);
	if(sockid < 0 ){
		perror("error in creating socket\n");
		exit(1);
	}

	struct sockaddr_in server,client;
	server.sin_family = AF_INET;   //ip family
	server.sin_port = htons(8086); //port number
	server.sin_addr.s_addr = inet_addr("127.0.0.1"); //ip of server

	int b = bind(sockid,(struct sockaddr*)&server,sizeof(server));
	if(b == -1){
		close(sockid);
		perror("binding failed");
		exit(1);
	}


	int status = listen(sockid,1); //queue limit 1
	if(status == -1){
		close(sockid);
		perror("listen failed");
		exit(1);
	}
	
	int len = sizeof(client);
	int con = accept(sockid,(struct sockaddr*)&client,&len);
	if(con<0){
		perror("socket() failed!!");
		exit(1);
	}
	int ch;
	recv(con,&ch,sizeof(ch),0);
	printf("%d\n",ch);
	struct student s1[10];
	strcpy(s1[0].name,"Manoj");
	strcpy(s1[0].regno,"160911164");

	strcpy(s1[0].address,"14th block");
	strcpy(s1[0].name,"Manoj");

	char buf[50];

	
	glob_var = mmap(NULL, sizeof *glob_var, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
	*glob_var = 0;
	int pid1 = fork();
	int pid2 = fork();
	if(pid1 == 0 && pid2 == 0){
		//child 1
        	if(ch==1){
		recv(con,buf,sizeof(buf),0);
		printf("%s\n",buf);
		int i;
		for(i=0;i<10;i++){
			if(strcmp(s1[i].regno,buf)==0){
				int mypid = getpid();
				send(con,&mypid,sizeof(int),0);
				send(con,s1[i].name,sizeof(s1[i].name),0);
				send(con,s1[i].address,sizeof(s1[i].address),0);
			
			}
		}
		*glob_var = 1;
	}
}
	else if(pid1>0 && pid2 == 0){
		//child 2
	
	}
	else if(pid1==0 && pid2 > 0){
		//child 3	
	}
	else{
	}
	while(*glob_var ==0){}		
	return 0;
}
