#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<arpa/inet.h>
#include<netinet/in.h>
#include<unistd.h> 

/* netinet/in.h for structures
   sys/types for datatypes
   socket for socket system calls
   arpa/inet for conversion functions
   unistd for close() call
*/

int main(void){
int i;
	
int skt = socket(PF_INET,SOCK_STREAM,0);

if(skt == -1){
	perror("Error creating socket");
	exit(1);
}

struct sockaddr_in server;
server.sin_family = AF_INET;
server.sin_addr.s_addr = inet_addr("127.0.0.1");
server.sin_port = htons(30000);

int con = connect(skt,(struct sockaddr*)&server,sizeof(server));
if(con == -1){
	perror("Error connecting");
	exit(1);
}

int arr[100];
int size;
//input
printf("Enter size of array and the array\n");
scanf("%d",&size);
for(i=0;i<size;i++)
	scanf("%d",&arr[i]);

send(skt,&size,sizeof(size),0);//send size of array
send(skt,arr,sizeof(arr),0);//send array

printf("Enter choice:\n");
printf("1.binary search 2.Sort 3.even/odd 4.linear search 5.exit\n");
int ch=5,key,eve=0;
scanf("%d",&ch);
send(skt,&ch,sizeof(int),0);
switch(ch){
case 1:
	printf("Enter key to be searched:\n");
	scanf("%d",&key);
	send(skt,&key,sizeof(key),0);
	//sent
	recv(skt,&key,sizeof(key),0);
	printf("The index is : %d",key);
	printf("\n");
	break;
case 2:
	printf("enter ascending(0) or descending(1) \n");
	scanf("%d",&key);
	send(skt,&key,sizeof(key),0);
	//sent
	recv(skt,arr,sizeof(arr),0);
	for(i=0;i<size;i++)
		printf("%d ",arr[i]);
	printf("\n");
	break;
case 3:
	recv(skt,&eve,sizeof(int),0);
	recv(skt,arr,sizeof(arr),0);
	printf("Even:  ");
	for(i=0;i<eve;i++)
		printf("%d ",arr[i]);
	printf("\nOdd: ");
	for(i=eve;i<size;i++)
		printf("%d ",arr[i]);
	printf("\n");
	break;
case 4:
	printf("Enter key to be searched:\n");
	scanf("%d",&key);
	send(skt,&key,sizeof(key),0);
	//sent
	recv(skt,&key,sizeof(key),0);
	printf("The index is : %d",key);
	printf("\n");
	break;
case 5:
	exit(0);
}

return 0;
}
