#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<arpa/inet.h>
#include<netinet/in.h>
#include<unistd.h> 

/* netinet/in.h for structures
   sys/types for datatypes
   skt for socket system calls
   arpa/inet for conversion functions
   unistd for close() call
*/
int linear_search(int* arr,int n,int key){
	int i=0;
	for(i=0;i<n;i++)
		if(arr[i]==key)
			return i;
	return -1;
}
int binary_search(int* arr,int n,int key){
	int l = 0;
	int r = n-1;
	int mid;
	while(l<=r){
		mid = l + (r-l)/2;
		if(arr[mid]==key)
			return mid;
		else if(arr[mid]<key)
			l = mid+1;
		else
			r = mid-1;
	}
	return -1;
}
int compare(int a,int b,int flg){
	if(!flg)
		return (a > b);
	else
		return (a < b);
}

void swap(int *a,int *b){
	int c = *a;
	*a = *b;
	*b = c;
}

void selection_sort(int*arr,int n,int flg){
	int min=0,tmp=0;
	int i,j;
	for(i=0;i<n-1;i++){
	min = i;
		for(j=i+1;j<n;j++)
			if(!compare(arr[j],arr[min],flg))
				min=j;
	swap(&arr[i],&arr[min]);
	}
}

void bubble_sort(int* arr,int n,int flg){
	int i,j;
	for(i=0;i<n-1;i++){
		for(j=0;j<n-1-i;j++){
			if(compare(arr[j],arr[j+1],flg)){
				swap(&arr[j],&arr[j+1]);
			}
		}
	}
	for(i=0;i<n;i++)
		printf("%d ",arr[i]);
}

void split(int* arr,int size,int* eve){
	int l = size;
	int j = -1;
	int i=0;
	for(i=0;i<l;i++){
		if(arr[i]%2==0){
			j++;
			swap(&arr[i],&arr[j]);
		}
	}
	*eve = j+1;//setting even count
}



int main(){
	
int skt = socket(PF_INET,SOCK_STREAM,0);

if(skt == -1){
	perror("Error creating skt");
	exit(1);
}

struct sockaddr_in server,client;
server.sin_family = AF_INET;
server.sin_addr.s_addr = inet_addr("127.0.0.1");
server.sin_port = htons(30000);

int b = bind(skt,(struct sockaddr *)&server,sizeof(server));
if(b == -1){
	perror("Error binding");
	exit(1);
}
int i;
while(1){

int l = listen(skt,1);
int cl_size = sizeof(client);
int acc = accept(skt,(struct sockaddr *)&client,(socklen_t *)&cl_size);
printf("accepted\n");
int arr[100];
int size;

recv(acc,&size,sizeof(size),0);//recv size
recv(acc,arr,sizeof(arr),0);//rec
printf("received array\n");
int ch=5,key,ans;
recv(acc,&ch,sizeof(int),0);
int eve = 0;
switch(ch){
case 1:
	recv(acc,&key,sizeof(key),0);
	ans = binary_search(arr,size,key);
	send(acc,&ans,sizeof(ans),0);
	break;
case 2:
	recv(acc,&key,sizeof(int),0);
	//do sort
	selection_sort(arr,size,key);
	send(acc,arr,sizeof(arr),0);
	break;
case 3:
	split(arr,size,&eve);
	printf("split done\n");
	send(acc,&eve,sizeof(int),0);
	send(acc,arr,sizeof(arr),0);
	break;
case 4:
	recv(acc,&key,sizeof(key),0);
	ans = linear_search(arr,size,key);
	send(acc,&ans,sizeof(ans),0);
	break;
case 5:
	exit(1);
}
}
return 0;
}
